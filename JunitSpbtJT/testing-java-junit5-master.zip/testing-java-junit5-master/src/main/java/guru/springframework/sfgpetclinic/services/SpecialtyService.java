package guru.springframework.sfgpetclinic.services;

import guru.springframework.sfgpetclinic.model.Speciality;

public interface SpecialtyService extends CrudService<Speciality, Long> {
}
