package guru.springframework.sfgpetclinic.fauxspring;

import guru.springframework.sfgpetclinic.model.Pet;

public interface ModelMap {
    void put(String pet, Pet pet1);
}
